import React from 'react'


const Tech_Dashboard = () => {


  return (
    <>
        {/* <!-- Scroll to Top Button--> */}
        <a className="scroll-to-top rounded" href="#page-top">
            <i className="fas fa-angle-up"></i>
        </a>

        

    </>
  )
}

export default Tech_Dashboard;